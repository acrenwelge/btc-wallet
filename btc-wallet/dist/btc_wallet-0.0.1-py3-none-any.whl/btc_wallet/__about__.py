# SPDX-FileCopyrightText: 2022-present Andrew Crenwelge <andrewcrenwelge@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = '0.0.1'
