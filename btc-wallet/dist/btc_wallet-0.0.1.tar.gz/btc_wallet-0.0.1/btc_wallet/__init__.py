# SPDX-FileCopyrightText: 2022-present Andrew Crenwelge <andrewcrenwelge@gmail.com>
#
# SPDX-License-Identifier: MIT

from pycoin.symbols.btc import networkj
print("hello")
